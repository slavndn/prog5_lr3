def hello_world():
    print("Hello World. If you are reading this message, then you have succeeded in importing the package")

hello_world()