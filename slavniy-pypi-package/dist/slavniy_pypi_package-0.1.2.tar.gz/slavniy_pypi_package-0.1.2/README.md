This is a simple exercise to publish a package onto PyPi. 
In order to understand what the package is capable of, you need to run the command "from slavniyDM import main"
